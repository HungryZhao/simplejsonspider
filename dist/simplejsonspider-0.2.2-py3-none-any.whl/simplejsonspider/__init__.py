# simplejsonspider/__init__.py

from .spider import SimpleJSONSpider
